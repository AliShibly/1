import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-my-jobs',
  standalone: false,
  templateUrl: './my-jobs.component.html',
  styleUrl: './my-jobs.component.css'
})
export class MyJobsComponent {
  categoryObj: any = {
    "CategoryId":0,
    "CategoryName":"",
    "ImageUrl":"",
    "IsActive":false
  }

  constructor(private http: HttpClient){

  }
  onSave() {
    debugger;
    this.http.post('https://localhost:44315/api/Category/saveCategory' ,this.categoryObj).subscribe((res:any)=> {
      debugger;
    })
  }
}
