import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { JobService } from '../../services/job.service';

@Component({
  selector: 'app-jobs',
  standalone: false,
  templateUrl: './jobs.component.html',
  styleUrl: './jobs.component.css'
})
export class JobsComponent {
  jobList: any []= [];
  constructor(private jobSer: JobService, private router: Router){

  }
  ngOnInit(): void {
    this.loadJobs();
  }

  loadJobs() {
    this.jobSer.GetActiveJobs().subscribe((res:any)=>{
      this.jobList = res.data;
    })
  }
  openJob(id: number) {
    this.router.navigate(['/job-details',id])
  }
}
