# job-portal-demo

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/job-portal-demo)