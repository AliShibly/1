import './polyfills';
import { enableProdMode } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { provideRouter } from '@angular/router';
import { routes } from './app/app-routing.module';
import { LoginSignupService } from './app/login-signup.service';
import { NotifyService } from './app/notify.service';

bootstrapApplication(AppComponent, {
  providers: [provideRouter(routes), 
      LoginSignupService,
    NotifyService
  ]
}).catch(err => console.error(err));
