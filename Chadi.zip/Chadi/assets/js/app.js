let tempResult;
let score = 0;
let number = 1;

function doMath(a, b, c) {
  switch (a) {
    case "+":
      return b + c;
    case "-":
      return b - c;
    case "*":
      return b * c;
    case "/":
      return b / c;
  }
}

function submitAnswer(result) {
  var userAnswerInput = document.getElementById("input");
  var feedback = document.getElementById("feedback");
  if(userAnswerInput.value == tempResult)
  {
    score++;
    number++;
    feedback.innerHTML = "Correct!";
    setTimeout(randomCreator, 1000);
  } 
  else {
    feedback.innerHTML = "Incorrect! Try again.";
  }
}


function randomCreator() {
  if(number > 10){
    document.getElementsByClassName("container").innerHTML = "You got " + score + "/10";
    return;
  }

  var operators = ["+", "-", "*", "/"];
  var randomIntOne = parseInt((Math.random() * 100), 10);
  var randomIntTwo = parseInt((Math.random() * 100), 10);
  var randomOperator = operators[Math.floor(Math.random() * operators.length)];
  document.getElementById("input").value = "";
  document.getElementById("feedback").innerHTML = "";
  var puzzle = document.getElementById("puzzle");
  puzzle.innerHTML = number+ ". What is "+randomIntOne+ " "+randomOperator+" "+randomIntTwo+ "?";

  tempResult = doMath(randomOperator, randomIntOne, randomIntTwo);
  console.log(tempResult);
}